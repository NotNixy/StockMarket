"""The dashboard.

Run from the repo root:

    streamlit run tournament/app.py

It starts on SYNTHETIC data so it works before any Bursa data exists -- every
panel is live, the numbers are just made up. The banner says so, loudly, and
it does not go away until you point DATA_DIR at a real cache.

Four tabs, in the order you would actually use them:

  Tournament  -- the daily decision. Where you stand, what wins, add or cut risk.
  Backtest    -- the strategy against every baseline it has to beat.
  Universe    -- what was tradable, and why things were excluded.
  Data health -- the ten integrity checks.
"""
from __future__ import annotations

import sys
from pathlib import Path

# Streamlit puts the SCRIPT's directory on sys.path, not the working directory,
# so `core` and `research` are invisible when launched as
# `streamlit run tournament/app.py`. Put the repo root on the path first.
_ROOT = Path(__file__).resolve().parent.parent
if str(_ROOT) not in sys.path:
    sys.path.insert(0, str(_ROOT))

import numpy as np
import pandas as pd
import streamlit as st

st.set_page_config(page_title="Bursa", layout="wide",
                   initial_sidebar_state="expanded")


# --------------------------------------------------------------------------
# Imports, guarded
# --------------------------------------------------------------------------
# Streamlit Community Cloud REDACTS the message of any uncaught exception:
#
#   ImportError: This app has encountered an error. The original error message
#   is redacted to prevent data leaks.
#
# For an ImportError the message is the entire diagnosis -- "cannot import
# name X from Y" versus "No module named matplotlib" are different problems
# with different fixes, and the redacted version distinguishes them not at
# all. A whole debugging session went into an error that says nothing.
#
# Catching it here and rendering our OWN string defeats the redaction: the
# text below is authored by this file, not by the exception handler, so
# Streamlit passes it through. Everything shown is repository structure and
# package versions -- no data, which is what the redaction exists to protect.
def _fail(title: str, exc: Exception) -> None:
    st.error(f"**{title}**\n\n`{type(exc).__name__}: {exc}`")
    st.markdown(
        "Most likely causes, in the order worth checking:\n\n"
        "1. **The deployed build is stale.** If this repo looks correct on "
        "GitHub, the running container is on an older commit. Manage app "
        "-> Reboot. This is the usual one.\n"
        "2. **A package is missing.** `requirements.txt` must sit in the "
        "repo root or beside this file; Cloud reads nowhere else.\n"
        "3. **A name genuinely moved** between modules.")

    with st.expander("Diagnostics"):
        st.write("**Repo root on sys.path:**", str(_ROOT))
        st.write("**Root contents:**",
                 sorted(p.name for p in _ROOT.iterdir()) if _ROOT.exists()
                 else "MISSING")
        pkg = _ROOT / "tournament"
        st.write("**tournament/ contents:**",
                 sorted(p.name for p in pkg.iterdir()) if pkg.exists()
                 else "MISSING")
        # What the module ACTUALLY exports, which is the answer whenever the
        # error is "cannot import name".
        try:
            import tournament.charts as _c
            st.write("**tournament.charts exports:**",
                     sorted(n for n in dir(_c) if not n.startswith("_")))
            st.write("**loaded from:**", getattr(_c, "__file__", "?"))
        except Exception as e:            # noqa: BLE001 - diagnostic path
            st.write("**tournament.charts failed to import:**",
                     f"{type(e).__name__}: {e}")
        for mod in ("matplotlib", "scipy", "pandas", "numpy", "pyarrow"):
            try:
                st.write(f"**{mod}:**", __import__(mod).__version__)
            except Exception as e:        # noqa: BLE001 - diagnostic path
                st.write(f"**{mod}:**", f"NOT AVAILABLE ({type(e).__name__})")
        st.write("**sys.path:**", sys.path)
    st.stop()


try:
    from core.costs import MOOMOO, SlippageModel, round_trip_pct
    from core.validate import validate
    from research.backtest import BacktestConfig, run_backtest
    from research.baselines import (
        percentile_vs_random, run_buy_and_hold, run_equal_weight,
        run_random_trials,
    )
    from research.harness_check import synth_panel
    from research.strategies import PRESETS
    from research.walkforward import walk_forward
    from tournament.charts import (
        DARK, LIGHT, equity_chart, gap_chart, pwin_chart,
        random_distribution_chart, universe_chart, walkforward_chart,
    )
    from tournament.standing import Contest, assess, strategy_table
except ImportError as exc:
    _fail("The app could not import its own modules.", exc)

DATA_DIR = Path("data/raw")


# --------------------------------------------------------------------------
# Data
# --------------------------------------------------------------------------
@st.cache_data(show_spinner=False)
def load_data(use_real: bool):
    """Real cache if it exists and was asked for, otherwise synthetic."""
    if use_real and DATA_DIR.exists() and any(DATA_DIR.glob("*.parquet")):
        from core.loader import load_panel
        panel = load_panel(raw_dir=DATA_DIR)
        panel["eligible"] = True          # real screen needs the SC list
        return panel, True
    return synth_panel(n_tickers=40, n_days=750, seed=1), False


@st.cache_data(show_spinner=False)
def run_everything(panel: pd.DataFrame, preset: str, top_n: int,
                   n_random: int):
    cfg = BacktestConfig(capital=10_000, rebalance="ME", broker=MOOMOO,
                         slippage=SlippageModel(15.0, 0.0), max_positions=top_n)
    strat = PRESETS[preset](top_n=top_n)
    res = run_backtest(panel, strat.signal, cfg)
    bh = run_buy_and_hold(panel, cfg)
    ew = run_equal_weight(panel, cfg)
    randoms = run_random_trials(panel, top_n, cfg, n_trials=n_random, seed=0)
    return strat, res, bh, ew, randoms, cfg


# --------------------------------------------------------------------------
# Sidebar
# --------------------------------------------------------------------------
st.sidebar.title("Bursa")

dark = st.sidebar.toggle("Dark charts", value=False)
theme = DARK if dark else LIGHT

st.sidebar.subheader("Contest")
n_entrants = st.sidebar.number_input("Entrants", 2, 5000, 400, step=10)
total_days = st.sidebar.number_input("Contest length (trading days)", 1, 250, 21)
field_vol = st.sidebar.slider(
    "Assumed field volatility", 0.02, 0.30, 0.05, 0.01,
    help="Volatility of a typical entrant over the whole contest. ~5% if the "
         "field holds diversified portfolios. Raise it if you think other "
         "entrants are also concentrating -- your edge shrinks sharply.")
my_return = st.sidebar.slider("My return so far", -0.50, 1.00, 0.03, 0.01)
days_left = st.sidebar.number_input("Trading days remaining", 0, 250, 15)

st.sidebar.subheader("Strategy")
preset = st.sidebar.selectbox("Preset", list(PRESETS), index=0)
top_n = st.sidebar.slider("Positions held", 1, 10, 3)
n_random = st.sidebar.select_slider("Random baseline trials",
                                    [20, 40, 60, 100], value=40)

st.sidebar.subheader("Data")
use_real = st.sidebar.checkbox("Use cached Bursa data if present", value=True)

panel, is_real = load_data(use_real)
contest = Contest(n_entrants=int(n_entrants), field_vol=float(field_vol),
                  total_days=int(total_days))

if not is_real:
    st.warning(
        "**Synthetic data.** Every figure below is generated from random "
        "walks, not Bursa. The dashboard is live; the numbers are invented. "
        f"Populate `{DATA_DIR}` with `core.loader.fetch_many()` to replace them.",
        icon="⚠️")

tab_t, tab_b, tab_w, tab_u, tab_d = st.tabs(
    ["Tournament", "Backtest", "Walk-forward", "Universe", "Data health"])


# --------------------------------------------------------------------------
# Tournament
# --------------------------------------------------------------------------
with tab_t:
    s = assess(my_return, int(days_left), contest)

    c1, c2, c3, c4 = st.columns(4)
    c1.metric("My return", f"{s.my_return:+.1%}")
    c2.metric("Score that wins", f"{s.target:+.1%}",
              help="Expected maximum of n entrants -- derived from the entrant "
                   "count, not from a leaderboard.")
    c3.metric("Gap", f"{s.gap:+.1%}",
              delta="ahead" if s.gap <= 0 else "behind",
              delta_color="normal" if s.gap <= 0 else "inverse")
    c4.metric("P(win) at current risk", f"{s.p_win_current:.1%}",
              help=f"Rises to {s.p_win_aggressive:.1%} fully concentrated.")

    if s.gap <= 0:
        st.success(f"**{s.verdict}**")
    elif "FAR BEHIND" in s.verdict:
        st.error(f"**{s.verdict}**")
    else:
        st.info(f"**{s.verdict}**")

    st.pyplot(pwin_chart(strategy_table(contest), theme,
                         baseline=1 / contest.n_entrants))

    st.caption(
        "Read the gap between the top and bottom bars. Concentration is worth "
        "far more than skill over a contest this short: a genuinely excellent "
        "+5%/month edge, played with a diversified portfolio, loses to holding "
        "three names with no edge at all."
    )

    with st.expander("Required volatility, and the arithmetic behind it"):
        st.write(
            f"- Need roughly **{s.required_vol_remaining:.1%}** volatility over "
            f"the remaining {s.days_left} days "
            f"(**{s.required_daily_vol:.2%}/day**)\n"
            f"- P(win) holding current risk: **{s.p_win_current:.1%}**\n"
            f"- P(win) fully concentrated: **{s.p_win_aggressive:.1%}**\n"
            f"- Random chance: **{1 / contest.n_entrants:.2%}**")
        st.caption(
            "The target is the expected maximum of "
            f"{contest.n_entrants} draws at {contest.field_vol:.0%} volatility. "
            "It needs no leaderboard -- only the entrant count and an "
            "assumption about how the field behaves.")


# --------------------------------------------------------------------------
# Backtest
# --------------------------------------------------------------------------
with tab_b:
    strat, res, bh, ew, randoms, cfg = run_everything(
        panel, preset, int(top_n), int(n_random))

    perf = res.performance(strat.name, n_trials=1)
    pct = percentile_vs_random(perf.sharpe, randoms["sharpe"])

    c1, c2, c3, c4 = st.columns(4)
    c1.metric("Total return", f"{perf.total_return:+.1%}")
    c2.metric("Sharpe", f"{perf.sharpe:+.2f}")
    c3.metric("Max drawdown", f"{perf.max_drawdown:.1%}")
    c4.metric("vs random", f"{pct:.0f}th pctile",
              help="Percentile within the random-entry distribution at matched "
                   "exposure. Below ~90 and the signal is not doing much.")

    st.pyplot(equity_chart({
        strat.name: res.equity,
        "buy & hold": bh.equity,
        "equal weight": ew.equity,
    }, theme))

    st.pyplot(random_distribution_chart(randoms["sharpe"], perf.sharpe, theme))

    st.subheader("Against every baseline")
    table = pd.DataFrame([
        perf.as_row(),
        bh.performance("buy & hold").as_row(),
        ew.performance("equal weight, rebalanced").as_row(),
    ]).set_index("strategy")
    st.dataframe(
        table.style.format({
            "total_return": "{:+.2%}", "cagr": "{:+.2%}", "vol": "{:.2%}",
            "sharpe": "{:+.2f}", "sortino": "{:+.2f}", "max_dd": "{:.2%}",
            "calmar": "{:+.2f}", "hit_rate": "{:.1%}", "turnover": "{:.2f}",
            "dsr": "{:.3f}",
        }), use_container_width=True)

    c1, c2 = st.columns(2)
    c1.metric("Cost drag", f"{res.cost_drag:.2%}",
              help="Total trading costs as a fraction of starting capital.")
    c2.metric("Round trip on RM 1,000",
              f"{round_trip_pct(1000, cfg.broker, cfg.slippage):.2f}%")

    st.caption(
        "`dsr` is the deflated Sharpe -- the probability the true Sharpe "
        "exceeds zero once the number of variants tested is accounted for. It "
        "shows only when more than one trial is declared. Reporting a Sharpe "
        "without it, after trying fifty configurations, is the single most "
        "common way a backtest misleads its author."
    )


# --------------------------------------------------------------------------
# Walk-forward -- the only tab whose numbers are out-of-sample
# --------------------------------------------------------------------------
@st.cache_data(show_spinner="Running walk-forward...")
def run_wf(panel: pd.DataFrame, top_n: int, n_folds: int):
    cfg = BacktestConfig(capital=10_000, rebalance="ME", broker=MOOMOO,
                         slippage=SlippageModel(15.0, 0.0), max_positions=top_n)
    strategies = {n: (lambda n=n: PRESETS[n](top_n=top_n)) for n in PRESETS}
    return walk_forward(panel, strategies, cfg, n_folds=n_folds,
                        train_months=24, test_months=6, expanding=True,
                        holdout_months=12, verbose=False)


with tab_w:
    st.caption(
        "Every other tab reports numbers from data the strategy was chosen on. "
        "These are not: at each fold the best strategy on the training window "
        "is picked, then measured on months it has never seen."
    )
    n_folds = st.slider("Folds", 3, 8, 6)
    try:
        wf = run_wf(panel, int(top_n), int(n_folds))
    except Exception as e:
        st.error(f"Not enough history to walk forward: {e}")
        wf = None

    if wf and wf.folds:
        c1, c2, c3, c4 = st.columns(4)
        c1.metric("Mean in-sample SR", f"{wf.mean_is:+.2f}")
        c2.metric("Mean out-of-sample SR", f"{wf.mean_oos:+.2f}")
        c3.metric("Survival ratio", f"{wf.degradation:+.2f}",
                  help="OOS divided by IS. Below ~0.5 means most of the "
                       "apparent edge was fitted rather than found.")
        c4.metric("Stitched OOS Sharpe", f"{wf.stitched_sharpe:+.2f}",
                  help="The equity curve you would actually have lived "
                       "through, choosing as you went.")

        st.pyplot(walkforward_chart(wf.folds, theme))

        st.subheader("Fold by fold")
        st.dataframe(pd.DataFrame([{
            "fold": f.index,
            "train ends": f.train_end.date(),
            "test window": f"{f.test_start.date()} → {f.test_end.date()}",
            "chosen": f.chosen,
            "IS Sharpe": f.is_sharpe,
            "OOS Sharpe": f.oos_sharpe,
            "OOS return": f.oos_return,
            "OOS max DD": f.oos_maxdd,
        } for f in wf.folds]).style.format({
            "IS Sharpe": "{:+.2f}", "OOS Sharpe": "{:+.2f}",
            "OOS return": "{:+.2%}", "OOS max DD": "{:.2%}",
        }), use_container_width=True)

        if wf.holdout_start is not None:
            st.info(
                f"**Holdout from {wf.holdout_start.date()} has not been "
                f"touched.** Evaluate it once, at the very end, with "
                f"`research.walkforward.evaluate_holdout` — and count that as "
                f"a trial. Re-running it while adjusting the strategy turns it "
                f"into another training set.", icon="🔒")

        chosen = [f.chosen for f in wf.folds]
        if len(set(chosen)) == 1:
            st.warning(
                f"**{chosen[0]} was chosen in every fold**, so the selection "
                f"step never actually selected anything. This is a test of "
                f"that one strategy, not of a process for picking between "
                f"them.", icon="⚠️")


# --------------------------------------------------------------------------
# Universe
# --------------------------------------------------------------------------
with tab_u:
    if "eligible" in panel.columns and not is_real:
        st.info("Synthetic panel: every name is marked eligible. The real "
                "screen needs the SC Shariah list and a liquidity history.",
                icon="ℹ️")

    daily = (panel.groupby("date", observed=True)
                  .agg(n_listed=("ticker", "nunique"),
                       n_eligible=("eligible", "sum")))
    st.pyplot(universe_chart(daily, theme))

    c1, c2, c3 = st.columns(3)
    c1.metric("Tickers in panel", f"{panel['ticker'].nunique()}")
    c2.metric("Eligible today", f"{int(daily['n_eligible'].iloc[-1])}")
    c3.metric("Bars", f"{len(panel):,}")

    st.caption(
        "A universe that collapses to a handful of names for part of the "
        "period explains a lot of apparent alpha. Check this before trusting "
        "any backtest above."
    )


# --------------------------------------------------------------------------
# Data health
# --------------------------------------------------------------------------
with tab_d:
    results = validate(panel, verbose=False)
    n_pass = sum(r.passed for r in results)

    st.metric("Checks passed", f"{n_pass}/{len(results)}")

    for r in results:
        if r.passed:
            st.success(f"**{r.name}** — {r.message}", icon="✅")
        else:
            with st.expander(f"⚠️  **{r.name}** — {r.message}", expanded=False):
                if not r.sample.empty:
                    st.dataframe(r.sample, use_container_width=True)

    st.caption(
        "`extreme moves` and `calendar gaps` are expected to flag on a real "
        "panel — genuine 40% days and real suspensions both exist. They want "
        "reading, not fixing. Everything else failing means the data is broken."
    )
